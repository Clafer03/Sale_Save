﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Sale_Save.Models;
using Microsoft.AspNetCore.Http;

namespace Sale_Save.Controllers
{
    /*public static class SessionExtension
    {
        public static void SetObject(this ISession session, string key, object value)
        {
            session.SetString(key, JsonConvert.SerializeObject(value));
        }

        public static T GetObject<T>(this ISession session, string key)
        {
            var value = session.GetString(key);
            return value == null ? default(T) : JsonConvert.DeserializeObject<T>(value);
        }
    }*/
    public class ClientesController : Controller
    {
        private readonly sale_saveContext Context;

        public ClientesController(sale_saveContext context)
        {
            Context = context;
        }

        [Route("Clientes/CreateCliente")]
        public IActionResult CreateCliente(Cliente obj)
        {

            //var ObjS = HttpContext.Session.GetString("Cliente");
            /*var cli = (from t in Context.Productos
                        where t.IdProducto == id
                        join Marcas in Context.Marcas on t.IdMarca equals Marcas.IdMarca
                        join Categorias in Context.Categoria on t.IdCategoria equals Categorias.IdCategoria
                        select new carrito { p = t, m = Marcas, c = Categorias }).Single();*/


            if (ModelState.IsValid)
            {
                Context.Clientes.Add(obj);
                Context.SaveChanges();
                //return RedirectToAction("Index");

                HttpContext.Session.SetString("scliente", JsonConvert.SerializeObject(obj));
                return RedirectToAction("Index", "SS");

            }
            else
            {
                return View();
            }

            /*if (ObjSesion == null)
            {


                List<CarritoItem> compras = new List<CarritoItem>();
                compras.Add(new CarritoItem(prod, 1));
                HttpContext.Session.SetString("carrito", JsonConvert.SerializeObject(compras));
            }
            else
            {
                List<CarritoItem> compras = HttpContext.Session.GetObject<List<CarritoItem>>("carrito");
                compras.Add(new CarritoItem(prod, 1));
                HttpContext.Session.SetString("carrito", JsonConvert.SerializeObject(compras));
            }
            return View();*/
        }

        public IActionResult CerrarSesion() {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "SS");
        }
    }
}
