﻿function abrirFormulario() {
    htmlModal = document.getElementById("modal");
    htmlModal.setAttribute("class", "modale opened");
}

function cerrarModal() {
    htmlModal = document.getElementById("modal");
    htmlModal.setAttribute("class", "modale");
}

function filtroNombreProducto() {
    htmlModal = document.getElementById("modal_name");
    htmlModal.setAttribute("class", "modale_name opened");
}

function cerrarModalNombre() {
    htmlModal = document.getElementById("modal_name");
    htmlModal.setAttribute("class", "modale_name");
}

function filtroFecha() {
    htmlModal = document.getElementById("modal_date");
    htmlModal.setAttribute("class", "modal_date opened");
}

function cerrarModalfiltroFecha() {
    htmlModal = document.getElementById("modal_date");
    htmlModal.setAttribute("class", "modal_date");
}

function abrirFormulario() {
    htmlModal = document.getElementById("modal");
    htmlModal.setAttribute("class", "modale opened");
}

function cerrarModal() {
    htmlModal = document.getElementById("modal");
    htmlModal.setAttribute("class", "modale");
}
