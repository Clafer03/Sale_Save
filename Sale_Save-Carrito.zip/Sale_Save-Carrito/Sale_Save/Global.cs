﻿global using Sale_Save.Models;
global using Microsoft.EntityFrameworkCore;

